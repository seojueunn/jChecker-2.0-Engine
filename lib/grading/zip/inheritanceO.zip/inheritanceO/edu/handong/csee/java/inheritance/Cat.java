package edu.handong.csee.java.inheritance;

import edu.handong.csee.java.inheritance.Animal;
import edu.handong.csee.java.inheritance.Dog;
import edu.handong.csee.java.inheritance.Monkey;

public class Cat extends Animal {
	//overriding_resulting message: The static method in Cat
    public static void testClassMethod() {
        System.out.println("The static method in Cat");
    }
    //overriding_resulting message: The instance method in Cat
    public void testInstanceMethod() {
    	//hiding_using keyword "super"
    	super.testInstanceMethod();
        System.out.println("The instance method in Cat");
    }
    public static void main(String[] args) {
    	Animal dog = new Dog();			//polymorphism: Dog can be represented by Animal
    	Animal monkey = new Monkey();	//polymorphism: Monkey can be represented by Animal
    	
        Cat myCat = new Cat();
        Animal myAnimal = myCat;
        Animal.testClassMethod();
        myAnimal.testInstanceMethod();
        
        Animal.testClassMethod();
        dog.testInstanceMethod();
        
        Animal.testClassMethod();
        monkey.testInstanceMethod();
    }
}
