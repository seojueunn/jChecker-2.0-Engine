package edu.handong.csee.java.inheritance;

import edu.handong.csee.java.inheritance.Animal;

public class Dog extends Animal {
	//overriding_resulting message: The static method in Dog
    public static void testClassMethod() {
        System.out.println("The static method in Dog");
    }
    //overriding_resulting message: The instance method in Dog
    public void testInstanceMethod() {
    	//hiding_using keyword "super"
    	super.testInstanceMethod();
        System.out.println("The instance method in Dog");
    }
}
