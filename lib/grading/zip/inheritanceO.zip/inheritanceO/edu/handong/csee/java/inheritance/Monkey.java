package edu.handong.csee.java.inheritance;

import edu.handong.csee.java.inheritance.Animal;

public class Monkey extends Animal {
	//overriding_resulting message: The static method in Monkey
    public static void testClassMethod() {
        System.out.println("The static method in Monkey");
    }
    //overriding_resulting message: The instance method in Monkey
    public void testInstanceMethod() {
    	//hiding_using keyword "super"
    	super.testInstanceMethod();
        System.out.println("The instance method in Monkey");
    }
}
