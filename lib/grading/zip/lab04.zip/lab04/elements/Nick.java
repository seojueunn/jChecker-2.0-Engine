package edu.handong.csee.java.lab04.elements;

public class Nick {
    
    private String nickname;
    private int i = 0;
    private String count;
 
    public void setNickName(String name, int num) {
        nickname = name;
        i = num;
        count = Integer.toString(i);
    }
  
    public String getNickName(){
        return nickname.concat(count);
    }
  
 }